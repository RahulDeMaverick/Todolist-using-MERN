import React from 'react'

import './Todo.scss';

//import {Update} from './Update/Update';

export class Todos extends React.Component {
    

    constructor(props) {
        super(props);   
        this.sample= this.sample.bind(this);
    }



    sample2(t) {
       
        fetch('http://localhost:3001/todos/' + t, {
  method: 'DELETE',
})
.then(res => res.text()) // or res.json()
.then(res => console.log("rakkesh"+res))



    }

    sample1(t) {
       // <Update> </Update>
        console.log("shittt"+t)

        const url = 'http://localhost:3001/todos/'+ t;
   
  const options = {
    method: 'PUT',
    headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json;charset=UTF-8'
    },
    body: JSON.stringify({
        Name: 'update',
        Description: 'update'
      })
  };
  
  fetch(url, options)
    .then(response => {
      console.log(response.status);
    }); 
    }

  

    sample(p) {
        
        let btnval = [...document.getElementsByClassName(p+"p1")];
        let btnval1 = [...document.getElementsByClassName(p+"p2")];
        let btnval2 = [...document.getElementsByClassName(p+"p3")];
        let cr = [...document.getElementsByClassName(p+"createdate")];
        let ud = [...document.getElementsByClassName(p+"updatedate")];

               console.log(btnval)
               for(let i in btnval)
               {
                   console.log(btnval[i]);
                
                btnval[i].removeAttribute("hidden");
            }
            for(let i in btnval1)
            {
                console.log(btnval1[i]);
             
             btnval1[i].removeAttribute("hidden");
         }
         for(let i in btnval2)
         {
             console.log("abhinow"+btnval2[i]);
          
          btnval2[i].removeAttribute("hidden");
          for(let i in cr)
          {
           
           cr[i].removeAttribute("hidden");
       }
       for(let i in ud)
       {
        ud[i].removeAttribute("hidden");
    }
      }

        }

    

    render() {
        

        const todoElements = this.props.todos.map((c, i) => <div className = "divcss">
            <h1 className={c._id + "btn"} onClick={() =>
            this.sample(c._id)} key={i}>{c.Name} </h1> 
            <p className={c._id + "p1"} hidden={true}>{c.Description}</p>
            <p className={c._id + "createdate"} hidden={true}>{c.createdDate}</p>
            <p className={c._id + "updatedate"} hidden={true}>{c.lastModifiedDate}</p>
            <button 
           onClick={() =>this.sample1(c._id)}
           //onClick={ this.onClick }
            className={c._id + "p2"}  hidden={true}  >update</button> 
                <button onClick={() =>
                    this.sample2(c._id)} className={c._id + "p3"} hidden={true}>delete</button>    
                     </div>);
        
        return (
            <div className="todo-container">TODOs
                <ul>
                    {todoElements}
                </ul>
            </div>
        );
    }
}