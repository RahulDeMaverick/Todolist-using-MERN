import React from 'react'

import './update.scss';

export class Update extends React.Component{


    render() {
        const {Name,Description} = this.state
        return (
          <div>
            <form onSubmit={this.submitHandler}>
              <div>
            <input type="text" placeholder="Name"  name="Name"  value={Name} onChange={this.changeHandler}></input> </div>
            <div>
            <input type="text"  placeholder="Description" name="Description"  value={Description} onChange={this.changeHandler}></input> </div>
            <button type="submit">submit</button>

            </form>
          </div>
         
        )
      }

}